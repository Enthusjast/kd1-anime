# ManimCE 0.20.1 Updater Recipe

适用：ValueTracker、动态标签、跟随点和随时间变化的图形。

## 约束

- 用 `ValueTracker` 表达单一连续参数，用 `always_redraw` 构造依赖该参数的简单图形。
- updater 只做轻量计算，不在每帧创建不可控数量的对象。
- 不再需要时调用 `clear_updaters()`，避免跨阶段残留。

```python
from manim import *

class UpdaterRecipe(Scene):
    def construct(self):
        tracker = ValueTracker(0)
        dot = always_redraw(lambda: Dot(RIGHT * tracker.get_value(), color=YELLOW))
        self.add(dot)
        self.play(tracker.animate.set_value(3), run_time=2, rate_func=smooth)
        dot.clear_updaters()
        self.wait(1)
```
