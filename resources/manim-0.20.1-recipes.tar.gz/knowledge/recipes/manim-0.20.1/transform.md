# ManimCE 0.20.1 Transform Recipe

适用：同一对象状态的连续变化、公式推导和视觉焦点迁移。

## 约束

- `Transform(source, target)` 会就地改变 source，target 只是目标快照。
- 需要让目标对象成为场景中的新活动对象时，使用 `ReplacementTransform`。
- 不要在目标尚未引入时对其执行普通动画；不要在 `FadeOut` 后继续使用旧活动对象。
- 变换前后保持颜色语义和布局锚点稳定。

```python
from manim import *

class TransformRecipe(Scene):
    def construct(self):
        square = Square(color=BLUE)
        circle = Circle(color=BLUE)
        self.play(Create(square))
        self.play(Transform(square, circle), run_time=1.5)
        self.wait(1)
```
