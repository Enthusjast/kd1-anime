# ManimCE 0.20.1 LaTeX Recipe

适用：中文公式、数学符号和跨场景公式交接。

## 约束

- 使用 `xelatex` 与 `.xdv`，模板加载 `ctex`。
- 每次 `Tex`/`MathTex` 调用显式传入同一个 `tex_template`。
- 复杂公式需要 `substrings_to_isolate` 或拆成多个公式对象；只有确认子串对应时才用 `TransformMatchingTex`。

```python
from manim import *

class LatexRecipe(Scene):
    def construct(self):
        tex_template = TexTemplate(tex_compiler="xelatex", output_format=".xdv")
        tex_template.add_to_preamble(r"\usepackage{ctex}")
        config.tex_template = tex_template
        formula = MathTex(r"\frac{a}{b}", tex_template=tex_template)
        self.play(Write(formula))
        self.wait(1)
```

## 风险

Python 普通字符串中的反斜杠命令必须使用 raw string 或双反斜杠；不要混用 pdflatex 专属模板。
