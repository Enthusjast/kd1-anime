# ManimCE 0.20.1 ThreeDScene Recipe

适用：三维坐标系、曲面、三维点和受控镜头运动。

## 约束

- `Surface`、`ThreeDAxes` 等对象必须位于 `ThreeDScene`。
- 使用 `set_camera_orientation` 设置初始视角；用 `move_camera` 或有限的 ambient rotation 做镜头变化。
- 需要固定在屏幕上的标题/公式时，使用 `add_fixed_in_frame_mobjects`。
- 限制 Surface 的 `resolution`，避免渲染时间和显存失控。

```python
from manim import *
import numpy as np

class ThreeDRecipe(ThreeDScene):
    def construct(self):
        self.set_camera_orientation(phi=70 * DEGREES, theta=-45 * DEGREES)
        axes = ThreeDAxes()
        surface = Surface(
            lambda u, v: axes.c2p(u, v, np.sin(u) * np.cos(v)),
            u_range=[-2, 2], v_range=[-2, 2], resolution=(12, 12),
            fill_opacity=0.6,
        )
        self.play(Create(axes), Create(surface))
        self.wait(1)
```

## 风险

OpenGL 下禁止 `self.camera.frame`；不要把三维对象放到普通 `Scene`。
