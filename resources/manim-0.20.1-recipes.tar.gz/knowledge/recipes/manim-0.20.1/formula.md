# ManimCE 0.20.1 Formula Recipe

适用：Cairo/OpenGL，主题为逐步展示公式、等式变形和最终结论。

## 约束

- 数学公式使用 `MathTex`，普通中文使用 `Text` 或配置了 XeLaTeX 的 `Tex`。
- 公式变形优先使用 `Transform`；只有两侧子串明确对应时才使用 `TransformMatchingTex`。
- 每个公式对象先通过 `Write`/`FadeIn` 引入，再执行变换。
- 长公式先拆成多个短对象或缩放，不把多个不相关公式堆在同一行。

```python
from manim import *

class FormulaRecipe(Scene):
    def construct(self):
        first = MathTex(r"(a+b)^2", color=YELLOW)
        second = MathTex(r"a^2+2ab+b^2", color=YELLOW)
        self.play(Write(first))
        self.wait(0.5)
        self.play(Transform(first, second))
        self.wait(1)
```

## 风险

不要直接访问无法确认存在的公式下标；不要在 `MathTex` 内嵌套 `equation` 环境。
