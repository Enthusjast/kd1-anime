# ManimCE 0.20.1 Graphing Recipe

适用：坐标系、函数图像、参数曲线和含定义域限制的函数。

## 约束

- 先创建 `Axes`/`NumberPlane`，再创建曲线并使用 `Create` 绘制。
- 有间断点、根式或对数定义域限制时，显式传入合法的 `x_range`；不要跨越奇点绘制一条曲线。
- 坐标范围应服务于当前教学重点，避免函数值把主要对象挤出画面。

```python
from manim import *

class GraphRecipe(Scene):
    def construct(self):
        axes = Axes(x_range=[-4, 4, 1], y_range=[-2, 8, 2])
        graph = axes.plot(lambda x: x**2, x_range=[-2.5, 2.5], color=BLUE)
        self.play(Create(axes))
        self.play(Create(graph), run_time=2)
        self.wait(1)
```

## 风险

`1/x` 等函数应分成两个合法区间；参数曲线函数必须返回三维向量。
