# ManimCE 0.20.1 Geometry Recipe

适用：三角形、正方形、面积标签、辅助线和可验证的基础几何关系。

## 约束

- 已知顶点时直接使用 `Polygon`，并明确顶点顺序。
- 不要用未经计算的坐标声称碎片“无缝拼接”或面积守恒。
- 关联的向量图形使用语义明确的 `VGroup`，组整体引入后再变换。

```python
from manim import *

class GeometryRecipe(Scene):
    def construct(self):
        triangle = Polygon(LEFT * 2, RIGHT * 2, UP * 2, color=BLUE)
        label = MathTex(r"A", color=YELLOW).next_to(triangle, DOWN)
        self.play(Create(triangle), Write(label))
        self.wait(1)
```

## 风险

任何切割、旋转和重组都必须给出可检查的顶点、面积和目标位置；否则改用轮廓、标签或等式表达。
