# ManimCE 0.20.1 Timing Recipe

适用：动画节奏、逐步揭示和复杂动画组合。

## 约束

- 重要公式和变换通常使用 1–2 秒；复杂变换使用 2–4 秒，并保留吸收停顿。
- 概念上同时发生的动画放在同一个 `self.play` 中；依次发生的动画使用多个 `self.play` 或 `Succession`。
- `LaggedStart` 只用于对象数量可控的渐进出现，并显式设置 `lag_ratio` 与 `run_time`。

```python
from manim import *

class TimingRecipe(Scene):
    def construct(self):
        dots = VGroup(*[Dot() for _ in range(4)]).arrange(RIGHT)
        self.play(LaggedStart(*[GrowFromCenter(dot) for dot in dots], lag_ratio=0.2), run_time=2)
        self.wait(1)
```
