# Manim Community Edition 0.20.1

- 上游版本标签：`v0.20.1`
- 来源：Manim 源码仓库的 `docs/source/`
- 内容：该版本的 Markdown 与 reStructuredText 文档

此目录用于 kd1-anime 的本地知识库；它不是当前项目代码的一部分。
